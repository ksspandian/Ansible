#!/usr/bin/perl
#############################################################################
# Licensed Materials - Property of IBM
#
#
# (C) Copyright IBM Corp. 2013, 2015           All Rights Reserved
#############################################################################
#############################################################################
# AG_lssecfixes_wrapper.pl    19 Jan 2015           Michael Haney MH
#
# Version 1.7
#
# Description:
#   Runs lssecfixes and formats output with AG approved parameters.
#
#   o The original version of this wrapper is posted in IBM Internal Open
#     Source Bazaar (IIOSB) https://w3.opensource.ibm.com/frs/?group_id=1419.  
#   o Ensure you are familiar with the Terms of Use for IIOSB tools and scripts
#     https://w3.opensource.ibm.com/ prior to the use of this wrapper.
#   o The requirement for this wrapper comes from the North America Patch
#     Management Project Office (previously Americas Group Patch Management
#     Project Office)
#
# Disclaimer:
#
#  This script is provided "AS IS" without any express or implied warranty,
#  including the implied warranties of merchantability, fitness for a 
#  particular purpose and non-infringement. IBM shall not be liable for any
#  direct, indirect, special or consequential damages resulting from the loss
#  of use, data or projects, whether in an action of contract or tort, arising
#  out of or in connection with the use or performance of this script.
#
#  It is licensed as IBM Internal/Mixed OSS
#
#  It is highly recommended that prior to wide usage of this wrapper, it is
#  tested in a pre-production environment that emulates your production 
#  environment.
#
# Input:
#   o Default processing runs without parameters (all advisories)
#   o m - Display only advisories for which the security fix is released but
#         "missing". (also -- missing)
#   o i - Display only advisories that have been installed.  
#         (also -- installed)
#   o h - Displays Help (also --help)
#
# Subroutines:
#     TIME_FORMATTED    - Turns current time into yyyymmdd;hh:mm:ss;zzz
#     RUN_CMD           - Executes a system command
#     GET_OPTIONS       - Gathers optional parameters
#     CHECK_CONFIG      - Checks lssecfixes.cfg
#     USAGE             - Prints Help
#     GET_DOMAIN        - Gathers domain from /etc/resolv.conf
#
# Output:
#   o Result code
#
# Requires:
#   o DEPENDENCIES: (All files required to run the script)
#     o ./lssecfixes.cfg
#     o ./secfixdb.$Config{ 'osname' }
#   o use Time::localtime qw(:FIELDS);
#   o use Getopt::Long;
#   o require "lssecfixes.cfg";
#   o 'sum' system command
#
# Return Codes:
#    0              Success
#   10              Uncaught error from lssecfixes
#   11              Error gathering sum
#   12              Missing lssecfixes.cfg
#   13              Invalid ag-custom type within lssecfixes.cfg
#   14              Database file empty
#   Other non-zero  Error condition passed from lssecfixes
#
#############################################################################
#############################################################################
# Modification Information:
#   08 May 13   MH  1.0     Initial  Release
#   20 May 13   MH  1.1     o Add lssecfixes uncaught error checking
#                           o Verify ag-custom type within lssecfixes.cfg
#                           o Added script exit
#                           o Added -m parameter to display only advisories for
#                             which the security fix is released but "missing"
#                           o Modify output delimiter (from ";" to "!")
#                           o Added lssecfixes version
#                           o Added uname -a output
#                           o Added -h help parameter
#   10 Jul 13   MH  1.2     In the event that the 'md5sum' command is not 
#                           available for the md5sum value calculation, added 
#                           a check/use of the 'csum' command.
#   26 Aug 13   MH  1.3     o Modify md5sum calculation to perform checksum
#                           calculation instead using 'sum' command.  This
#                           prevents errors on servers that do not have
#                           md5sum or csum installed.
#                           o Fixed start time format
#    5 Sep 13   MH  1.4     o Removed File::Path and File::Spec references
#                           o Added -i, --installed option.  Output is
#                             derived from comparison of all and missing
#                             options.
#    5 Nov 13   MH  1.5     o Added domain to fully qualify hostname
#   24 Jan 14   MH  1.6     o Hostname now derived as follows in order of
#                             precedence:
#                             1. $wrapper_display_name from lssecfixes.cfg
#                             2. hostname command
#                             3. uname -n command
#                             4. if still shortname, /etc/resolv.conf 
#                                domain setting appended to hostname
#                                command shortname
#                             5. hostname command shortname  
#   20 Jan 15   MH  1.7    o Ignore whitespace in domain setting within
#                            /etc/resolv.conf
#                          o Verify db file is not empty, rc=14
#                          o Add lssecfixes -n flag.  This, for AIX,
#                            prints out the advisory number rather than the
#                            APAR number. For other OS's, there is no
#                            change.                        
#
#############################################################################
use Getopt::Long;

undef $rc;
undef $cmdRC;
undef $cksumRC;
undef $cmd;
undef $hostname;
undef $uname;
undef $domain;
undef $checksum;
undef $data_type;
undef $cksum;
undef $startTime;
undef $endTime;
undef $lssecfixesVer;
undef $osVer;
undef $del;
undef $params;
undef $fixdb;
undef $blocks;
undef $elements;
undef $header;
undef @output;
undef @missing;
undef @tmp;
undef @cksum;
undef @lssecfixes;

$del            = "!";
$startTime      = &TIME_FORMATTED;
$lssecfixesVer  = `./lssecfixes --version`;
$osVer          = `uname -a`;

chomp $lssecfixesVer;
chomp $osVer ;

# --------------------
# Get params
# --------------------
&GET_OPTIONS();

# --------------------
# Get hostname
# --------------------
$hostname = `hostname`;
chomp $hostname;

# --------------------
# Not fully qualified
# --------------------
unless ($hostname =~ /\./) {
    $uname = `uname -n`;
    unless ($uname =~ /\./) {
        $rc = &GET_DOMAIN(\$domain);
        if ($rc) {
            $hostname = $hostname;
        } else {
            $hostname = $hostname . "." . $domain;
        }
    } else {
        $hostname = $uname;
    }
    chomp $hostname;
}

# ---------------------
# Verify lssecfixes.cfg
# ---------------------
$rc = &CHECK_CONFIG(\$hostname);
if ($rc) {
    push @lssecfixes, "$hostname${del}e${del}# Start time stamp${del}$startTime\n";
    push @lssecfixes, "$hostname${del}e${del}# Problem with lssecfixes.cfg, rc=$rc\n";
    $endTime = &TIME_FORMATTED;
    push @lssecfixes, "$hostname${del}e${del}# End time stamp${del}$endTime${del}returnCode=$rc\n";
    foreach (@lssecfixes) {
        print $_;
    }
    exit $rc;
}

# ---------------------
# Execute lssecfixes
# ---------------------
$cmd = "./lssecfixes $params 2>&1";
$cmdRC = &RUN_CMD($cmd, \@output);
if ($cmdRC) {
    # Error condition
    $rc = $cmdRC;
    push @lssecfixes, "$hostname${del}e${del}# Error executing $cmd, rc=$rc\n";
}

# ---------------------------
# Installed - build missing
# ---------------------------
if ($opt_installed) {
    # -----------------------
    # Build missing array
    # -----------------------
    $params = "-s ag-custom -Hnt\"${del}\"";
    $cmd = "./lssecfixes $params 2>&1";
    $cmdRC = &RUN_CMD($cmd, \@tmp);
    if ($cmdRC) {
        # Error condition
        $rc = $cmdRC;
        push @lssecfixes, "$hostname${del}e${del}# Error executing $cmd, rc=$rc\n";
    }
    
    foreach $line (@tmp) {
        if ($line =~ /^[0-9]{2}\//) {
            push @missing, $line;
        }
    }
}


# ---------------------
# Process output
# ---------------------
$fixdb = "false";
foreach $out (@output) {
    $match = "false";

    if ($cmdRC) {
        push @lssecfixes, "$hostname${del}e${del}$out\n";
    } else {
        # -----------------------------
        # Catch uncaught errors
        # -----------------------------
        if ($out =~ /fixDB/) {
            $fixdb = "true";
        }
        unless ($fixdb eq "true") {
            $rc = 10;
        }
    
        # -----------------------------
        # Get database file checksum
        # -----------------------------
        if ($out =~ /fixDB/) {
            ($tmp, $db_file) = split(/=/, $out);
            chomp $db_file;
            ($db_file, $tmp) = split(/,/, $db_file);
            chomp $db_file;
            
            $cmd = "which sum 2>&1";
            $cksumRC = &RUN_CMD($cmd, \@cksum);
            if ($cksumRC) {
                # Error condition
                $rc = 11;
                push @lssecfixes, "$hostname${del}e${del}# Cannot execute the sum command., rc=$rc\n";
                $out .= "${del}sum=error";
                $out .= "${del}lssecfixes_version=$lssecfixesVer";
                undef $cmd;
            } else {
                $cmd = "sum -r $db_file";
            }
            
            if ($cmd) {
                $cksumRC = &RUN_CMD($cmd, \@cksum);
                if ($cksumRC) {
                    # Error condition
                    $rc = 11;
                    push @lssecfixes, "$hostname${del}e${del}# Error executing $cmd, rc=$rc\n";
                    $out .= "${del}sum=error";
                    $out .= "${del}lssecfixes_version=$lssecfixesVer";
                } else {
                    ($cksum, $blocks) = split(/\s+/, $cksum[0]);
                    if (($cksum == 00000) && ($blocks == 0)) {
                        $db_file =~ s/\s+//;
                        $rc = 14;
                        push @lssecfixes, "$hostname${del}e${del}# Error: Database file \"$db_file\" is empty, rc=$rc\n";
                    }
                    $cksum = $cksum . "C" . $blocks . "B";
                    $out .= "${del}sum=$cksum";
                    $out .= "${del}lssecfixes_version=$lssecfixesVer";
                }
            }
        }

        # -----------------------------
        # Set datatype
        # -----------------------------
        if ( ($out =~ /^\#/) || ($out =~ /^DUE/) || ($fixdb eq "false") ) {
            $data_type = "e";
        } else {
            $data_type = "a";
        }
        
        # -----------------------------
        # Installed calculation
        # -----------------------------
        if ($opt_installed) {
            # -------------------------
            # Compare and set
            # -------------------------
            if ($data_type eq 'a') {
                $elements = scalar @missing;
                if ($elements > 0) {
                    if ($missing[0] eq $out) {
                        $match = "true";
                        shift @missing;
                    }
                    
                    if ($match eq "true") {
                        next;
                    }
                }
            }
        }

        # -----------------------------
        # Build output array
        # -----------------------------
        if ($data_type eq 'e') {
            if ($out =~ /^DUE/) {
                $out = "DATE ISSUED${del}DUE${del}SEV${del}ADVISORY${del}DESCRIPTION";
                push @lssecfixes, "$hostname${del}$data_type${del}# Start time stamp${del}$startTime\n";
                push @lssecfixes, "HOST${del}$data_type${del}$out\n";
             } elsif ($out =~ /fixDB/) {
                push @lssecfixes, "$hostname${del}$data_type${del}$out\n";
                push @lssecfixes, "$hostname${del}$data_type${del}# uname=$osVer\n";
            } else {
                push @lssecfixes, "$hostname${del}$data_type${del}$out\n";
            }
        } else {
            push @lssecfixes, "$hostname${del}$data_type${del}$out\n";
        }
    }
}

$endTime = &TIME_FORMATTED;
push @lssecfixes, "$hostname${del}e${del}# End time stamp${del}$endTime${del}returnCode=$rc\n";

foreach (@lssecfixes) {
    print $_;
}

exit $rc;


#############################################################################
# RUN_CMD
#
# Executes command string.
#
# Usage:
#   &RUN_CMD($cmdString, \$outputString);
#
# Input:
#   o Command String    - System command to execute
#   o Output String     - Reference to command output
#
# Output:
#   o Command return code
#
#############################################################################
sub RUN_CMD {
    my ($cmd_string, $output_ref) = @_;
    undef @_;
    my ($rc) = 0;

    @$output_ref=`$cmd_string 2>&1`;
    if ($? >= 256) {
        $rc = $?/256;
    } else {
        $rc = $?
    }

    # Format output string
    chomp(@$output_ref);

    return $rc;
}

##############################################################################
# TIME_FORMATTED
#
#  Returns a string denoting the local time
#
#  Requires: Time::localtime module
#
#  Returns:
#     String with formatted time: yyyymmdd!hh:mm:ss!zzz
#
#  Modification Log
#
##############################################################################
sub TIME_FORMATTED {
    use Time::localtime qw(:FIELDS);
    my (@arg, $month, $day, $hour, $minute, $second, $year, $tyear, $tz);
    @arg = @_;

    # Find the local time
    localtime;
    if (($tm_mon+1) < 10){ $month = "0".($tm_mon+1);} else { $month = ($tm_mon+1);}
    if (($tm_mday) < 10){ $day = "0".($tm_mday);} else { $day = ($tm_mday);}
    if (($tm_hour) < 10){ $hour = "0".($tm_hour);} else { $hour = ($tm_hour);}
    if (($tm_min) < 10){ $minute = "0".($tm_min);} else { $minute = ($tm_min);}
    if (($tm_sec) < 10){ $second = "0".($tm_sec);} else { $second = ($tm_sec);}
    $tyear = $tm_year - 100;
    if ($tyear < 10){ $year = "200".$tyear;} else {$year = "20".$tyear};
    
    # Get time zone
    $tz = "date \'+%Z\'";
    $tz = `$tz`;
    chomp $tz;

    # Build time stamp
    $slash_time = $year.$month.$day.${del}.$hour.":".$minute.":".$second.${del}.$tz;

    return ($slash_time);
}

##############################################################################
# GET_OPTIONS
#
#  This subroutine gets the override options, if any, from the command line.
#
##############################################################################
sub GET_OPTIONS {
    my $rc = 0;
    my $num_options = scalar(@ARGV);
    
    if ($num_options > 1) {
        &USAGE;
        exit 0;
    }

    GetOptions (
        "h|help|?"          => \$opt_help,
        "m|missing"         => \$opt_missing,
        "i|installed"       => \$opt_installed) || die "ERROR: (rc=$rc) A problem parsing the input arguments: $!";

    if ($opt_help) {
        &USAGE;
        exit 0;
    } else {
        if ($opt_missing) {
            $params = "-s ag-custom -Fnt\"${del}\"";
        } elsif ($opt_installed) {
            $params = "-s ag-custom -aFnt\"${del}\"";
        } else {
            $params = "-s ag-custom -aFnt\"${del}\"";
        }
    }

    return $rc;
}

##############################################################################
# CHECK_CONFIG
#
#  This subroutine verifies the ag-custom type within lssecfixes.cfg.
#
##############################################################################
sub CHECK_CONFIG {
    my $rc = 0;
    my ($hostname_ref) = @_;
 
    if ( -f "lssecfixes.cfg" ) {
        require "lssecfixes.cfg";
    } else {
        $rc = 12;
    }
    
    unless ($wrapper_display_name eq "") {
        $$hostname_ref = $wrapper_display_name; 
    }

    if ($SYSTEM_TYPE{ 'ag-custom' }{ 'schedule' }{ 'H' } != 1) {
        $rc = 13;
    }
    if ($SYSTEM_TYPE{ 'ag-custom' }{ 'schedule' }{ 'M' } != 1) {
        $rc = 13;
    }
    if ($SYSTEM_TYPE{ 'ag-custom' }{ 'schedule' }{ 'L' } != 1) {
        $rc = 13;
    }
    if ($SYSTEM_TYPE{ 'ag-custom' }{ 'schedule' }{ 'N' } != 0) {
        $rc = 13;
    }

    return $rc;
}

##############################################################################
# GET_DOMAIN
#
#  Returns server's domain
#
##############################################################################
sub GET_DOMAIN {
    my ($domain_ref) = @_;
    undef @_;
    my $rc           = 0;
    my $conffile     = "/etc/resolv.conf";
    my $line         = "";
    my $found        = "false";
 
    if ( -r $conffile ) {
        if (open(RESOLV_FILE, $conffile)) {
            while ($line = <RESOLV_FILE>) {
                # remove white space chars from beginning and end of string
                $line =~ s/^\s+//;
                $line =~ s/\s+$//;
                if ($line =~ /^domain\s*(.*)$/i) {
                    $$domain_ref = $1;
                    $found = "true";
                    last;
                }
            }
            close RESOLV_FILE;
        } else {
            $rc = 1;
        }
    } else {
        $rc = 1;
    }
    
    if ($found eq "false") {
        $rc = 1;
    }

    return $rc;
}

##############################################################################
# USAGE
#
#  Returns a usage statement
#
##############################################################################
sub USAGE {
    $rc = 0;
    my( $pager ) = "/bin/more";

    local *STDOUT if ( -x $pager );
    open( STDOUT, "|$pager" ) if ( -x $pager );

    print( "Description:\n");
    print( "  AG_lssecfixes_wrapper.pl is used to execute the lssecfixes tool \n");
    print( "                           in a manner consistent with AG requirements.\n");
    print( "\n");
    print( "  o The original version of this wrapper is posted in IBM Internal Open\n");
    print( "    Source Bazaar (IIOSB) https://w3.opensource.ibm.com/frs/?group_id=1419.\n");
    print( "  o Ensure you are familiar with the Terms of Use for IIOSB tools and scripts\n");
    print( "    https://w3.opensource.ibm.com/ prior to the use of this wrapper.\n");
    print( "  o The requirement for this wrapper comes from the North America Patch\n");
    print( "    Management Project Office (previously Americas Group Patch Management\n");
    print( "    Project Office)\n");
    print( "\n");
    print( "Disclaimer:\n");
    print( "  It is highly recommended that prior to wide usage of this wrapper, it is\n");
    print( "  tested in a pre-production environment that emulates your production\n");
    print( "  environment.\n");
    print( "\n");
    print( "  This script is provided \"AS IS\" without any express or implied warranty,\n");
    print( "  including the implied warranties of merchantability, fitness for a\n");
    print( "  particular purpose and non-infringement. IBM shall not be liable for any\n");
    print( "  direct, indirect, special or consequential damages resulting from the loss\n");
    print( "  of use, data or projects, whether in an action of contract or tort, arising\n");
    print( "  out of or in connection with the use or performance of this script.\n");
    print( "\n");
    print( "  It is licensed as IBM Internal/Mixed OSS\n");
    print( "\n");
    print( "Invocation assumptions:\n");
    print( "  o You must change your current working directory to the directory in which\n");
    print( "    AG_lssecfixes_wrapper.pl is installed.\n");
    print( "  o The lssecfixes command must be installed in the same directory as\n");
    print( "    AG_lssecfixes_wrapper.pl.  A symlink will suffice.\n");
    print( "  o The secfixdb.* file must be located relative to the directory\n");
    print( "    AG_lssecfixes_wrapper.pl is in, ../etc.  A symlink will suffice.\n");
    print( "  o The lssecfixes.cfg file must  be installed in the same directory as\n");
    print( "    AG_lssecfixes_wrapper.pl.  A symlink will suffice.\n");
    print( "  o The lssecfixes.cfg file must contain a stanza of:\n");
    print( "    \"ag-custom\",\n");
    print( "         {\n");
    print( "         \"name\", \"AG Custom class\",\n");
    print( "         \"schedule\",\n");
    print( "             {\n");
    print( "             H, 1,\n");
    print( "             M, 1,\n");
    print( "             L, 1,\n");
    print( "             N, 0\n");
    print( "             }\n");
    print( "         },\n");
    print( "\n");
    print( "lssecfixes parameters:\n");
    print( "  Default:      -s ag-custom -aFnt\"${del}\"\n");
    print( "  Missing:      -s ag-custom -Fnt\"${del}\"\n");
    print( "\n");
    print( "DUE Column Key:\n");
    print( "  '*'  = Security advisory is exposed.  Fix is missing.\n");
    print( "  '+'  = Security advisory is exposed and has a revision\n");
    print( "         level higher than the current system.\n");
    print( "         (e.g. 4.3.2.x -> 4.3.3.x).  Fix is missing.\n");
    print( "  'I'  = Security advisory resolved by installation of the corrective ptf.\n");
    print( "  'E'  = Security advisory resolved by installation of a corrective i-fix.\n");
    print( "  'W'  = Security advisory resolved by the implementation of a workaround or affected service not running.\n");
    print( "  'NA' = Security advisory does not apply.\n");
    print( "  'F'  = Security fix has not been released (future).\n");
    print( "  'A'  = Security fix has been released, but not formally announced.\n");
    print( "\n");
    print( "Syntax:\n");
    print( "  AG_lssecfixes_wrapper.pl [-h, --help | -i, --installed | -m, --missing]\n");
    print( "\n");
    print( "Options:\n");
    print( "  -h --help             Display this help screen\n");
    print( "  -i --installed        Display only \"installed\" advisories\n");
    print( "  -m --missing          Display only \"missing\" advisories\n");
    print( "\n");
    print( "Returns:\n");
    print( "   0              Success\n");
    print( "  10              Uncaught error from lssecfixes\n");
    print( "  11              Error gathering checksum\n");
    print( "  12              Missing lssecfixes.cfg\n");
    print( "  13              Invalid ag-custom type within lssecfixes.cfg\n");
    print( "  14              Database file empty\n");
    print( "  Other non-zero  Error condition passed from lssecfixes\n");
    print( "\n");

    return $rc;
}

